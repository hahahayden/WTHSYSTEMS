#include "part6.h"

struct point create_point(double x, double y)
{
   struct point p = {x, y};
   return p;
}

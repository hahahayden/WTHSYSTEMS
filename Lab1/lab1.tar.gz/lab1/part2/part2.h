#ifndef PART2_H
#define PART2_H

double calc(double);

#endif
